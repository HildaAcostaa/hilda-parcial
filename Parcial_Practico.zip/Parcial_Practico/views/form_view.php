﻿<?php
$err = $_SESSION['errors'] ?? [];
$old = $_SESSION['old']    ?? [];
unset($_SESSION['errors'], $_SESSION['old']);

function fieldError(array $err, string $key): string {
    if (!isset($err[$key])) return '';
    return '<span class="error-msg"> ' . htmlspecialchars($err[$key]) . '</span>';
}
function hasError(array $err, string $key): string {
    return isset($err[$key]) ? ' is-invalid' : '';
}
function oldVal(array $old, string $key): string {
    return htmlspecialchars($old[$key] ?? '');
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Capital Humano 2025 — Inscripción</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="wrapper">

    <nav class="nav-bar">
        <a href="index.php"   class="nav-btn active"> Inscripción</a>
        <a href="reporte.php" class="nav-btn"> Reporte</a>
    </nav>

    <header class="site-header">
        <div class="logo-badge">Capital Humano</div>
        <h1>Formulario de Inscripción</h1>
        <p>Cumbre de Desarrolladores Panamá &bull; <?= date('Y') ?></p>
    </header>

    <div class="card" style="padding:0">
    <?php if (!empty($_SESSION['success'])): ?>
        <div class="alert alert-success" style="margin:1.5rem 2rem 0">
             <?= $_SESSION['success'] ?>
        </div>
        <?php unset($_SESSION['success']); ?>
    <?php endif; ?>
    <?php if (!empty($err['general'])): ?>
        <div class="alert alert-danger" style="margin:1.5rem 2rem 0">
             <?= htmlspecialchars($err['general']) ?>
        </div>
    <?php endif; ?>
    </div>

    <form method="POST" action="controllers/InscriptorController.php" novalidate>
    <div class="card">

        <h2 class="section-title"> Datos Personales</h2>
        <div class="grid-2">
            <div class="form-group">
                <label>Identidad <span class="req">*</span></label>
                <input type="text" name="identidad" placeholder="Ej: 8-888-8888"
                       value="<?= oldVal($old,'identidad') ?>"
                       class="<?= hasError($err,'identidad') ?>" maxlength="20">
                <?= fieldError($err,'identidad') ?>
            </div>
            <div class="form-group">
                <label>Edad <span class="req">*</span></label>
                <input type="number" name="edad" placeholder="Años"
                       value="<?= oldVal($old,'edad') ?>"
                       class="<?= hasError($err,'edad') ?>" min="1" max="120">
                <?= fieldError($err,'edad') ?>
            </div>
            <div class="form-group">
                <label>Nombre <span class="req">*</span></label>
                  <input type="text" name="nombre" placeholder="Ej: Hilda"
                      value="<?= oldVal($old,'nombre') ?: 'Hilda' ?>"
                       class="<?= hasError($err,'nombre') ?>" maxlength="100">
                <?= fieldError($err,'nombre') ?>
            </div>
            <div class="form-group">
                <label>Apellido <span class="req">*</span></label>
                <input type="text" name="apellido" placeholder="Ej: Acosta"
                    value="<?= oldVal($old,'apellido') ?: 'Acosta' ?>"
                       class="<?= hasError($err,'apellido') ?>" maxlength="100">
                <?= fieldError($err,'apellido') ?>
            </div>
        </div>

        <div class="form-group" style="margin-top:1rem">
            <label>Sexo <span class="req">*</span></label>
            <div class="radio-group">
                <?php foreach (['M'=>'Masculino','F'=>'Femenino','Otro'=>'Otro'] as $v=>$l): ?>
                <label class="radio-item">
                    <input type="radio" name="sexo" value="<?= $v ?>"
                        <?= (($old['sexo'] ?? '') === $v) ? 'checked' : '' ?>>
                    <span><?= $l ?></span>
                </label>
                <?php endforeach; ?>
            </div>
            <?= fieldError($err,'sexo') ?>
        </div>

        <div class="divider"></div>

        <h2 class="section-title"> Residencia y Nacionalidad</h2>
        <div class="grid-2">
            <div class="form-group">
                <label>País de Residencia <span class="req">*</span></label>
                <select name="id_pais" class="<?= hasError($err,'id_pais') ?>">
                    <option value="">-- Seleccione un país --</option>
                    <?php foreach ($paises as $p): ?>
                    <option value="<?= $p['id_pais'] ?>"
                        <?= (($old['id_pais'] ?? '') == $p['id_pais']) ? 'selected' : '' ?>>
                        <?= htmlspecialchars($p['nombre_pais']) ?>
                    </option>
                    <?php endforeach; ?>
                </select>
                <?= fieldError($err,'id_pais') ?>
            </div>
            <div class="form-group">
                <label>Nacionalidad <span class="req">*</span></label>
                <input type="text" name="nacionalidad" placeholder="Ej: Panameña"
                       value="<?= oldVal($old,'nacionalidad') ?>"
                       class="<?= hasError($err,'nacionalidad') ?>" maxlength="100">
                <?= fieldError($err,'nacionalidad') ?>
            </div>
        </div>

        <div class="divider"></div>

        <h2 class="section-title"> Información de Contacto</h2>
        <div class="grid-2">
            <div class="form-group">
                <label>Correo Electrónico <span class="req">*</span></label>
                <input type="email" name="correo" placeholder="usuario@correo.com"
                       value="<?= oldVal($old,'correo') ?>"
                       class="<?= hasError($err,'correo') ?>" maxlength="150">
                <?= fieldError($err,'correo') ?>
            </div>
            <div class="form-group">
                <label>Celular <span class="req">*</span></label>
                <input type="tel" name="celular" placeholder="+507 6XXX-XXXX"
                       value="<?= oldVal($old,'celular') ?>"
                       class="<?= hasError($err,'celular') ?>" maxlength="20">
                <?= fieldError($err,'celular') ?>
            </div>
        </div>

        <div class="divider"></div>

        <h2 class="section-title"> Áreas Tecnológicas de Interés <span class="req">*</span></h2>
        <?= fieldError($err,'areas') ?>
        <div class="checkbox-grid" style="margin-top:.6rem">
            <?php foreach ($areas as $area): ?>
            <label class="checkbox-item">
                <input type="checkbox" name="areas[]" value="<?= $area['id_area'] ?>"
                    <?php
                    $oldAreas = array_map('intval', $old['areas'] ?? []);
                    echo in_array((int)$area['id_area'], $oldAreas) ? 'checked' : '';
                    ?>>
                <span><?= htmlspecialchars($area['nombre_area']) ?></span>
            </label>
            <?php endforeach; ?>
        </div>

        <div class="divider"></div>

        <h2 class="section-title"> Observaciones / Consulta</h2>
        <div class="form-group">
            <label>Observaciones (opcional)</label>
            <textarea name="observaciones"
                      placeholder="Escribe tus dudas o comentarios sobre el evento..."
                      maxlength="1000"><?= oldVal($old,'observaciones') ?></textarea>
        </div>

        <div class="divider"></div>

        <button type="submit" class="btn-submit">
             Registrarme
        </button>

    </div>
    </form>

    <footer class="site-footer">
        <strong>© <?= date('Y') ?> Capital Humano. All rights reserved.</strong><br>
         <a href="mailto:info@capitalhumano.pa">info@capitalhumano.pa</a>
        &nbsp;&bull;&nbsp;
         +507 6767-6767
        &nbsp;&bull;&nbsp;
         <a href="#">www.CapitalHumano.pa</a>
    </footer>

</div>
</body>
</html>
