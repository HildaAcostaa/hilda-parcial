﻿<?php ?>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Capital Humano 2025 — Reporte</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
<div class="wrapper">

    <nav class="nav-bar">
        <a href="index.php"   class="nav-btn"> Inscripción</a>
        <a href="reporte.php" class="nav-btn active"> Reporte</a>
    </nav>

    <header class="site-header">
        <div class="logo-badge">Capital Humano</div>
        <h1>Reporte de Inscripciones</h1>
        <p>Total registrados: <strong style="color:#34D399"><?= count($inscriptores) ?></strong></p>
    </header>

    <div class="card">
        <div style="display:flex; justify-content:space-between; align-items:center; margin-bottom:1rem; flex-wrap:wrap; gap:.75rem">
            <h2 class="section-title" style="margin:0">Participantes Registrados</h2>
            <?php if (!empty($inscriptores)): ?>
            <a href="exports/export.php" class="btn-export"> Exportar a Excel</a>
            <?php endif; ?>
        </div>

        <div style="display:flex; gap:1rem; margin-bottom:1.2rem; flex-wrap:wrap">
            <span class="badge badge-ok"> Íntegro — firma válida</span>
            <span class="badge badge-err"> Comprometido — datos alterados</span>
        </div>

        <?php if (empty($inscriptores)): ?>
        <div class="empty-state">
            <p style="font-size:1.1rem; font-weight:600; color:#34D399">Sin registros aún.</p>
            <p style="margin-top:.5rem"><a href="index.php" style="color:#06B6D4">Registrar el primero →</a></p>
        </div>
        <?php else: ?>
        <div class="report-table-wrap">
        <table class="report-table">
            <thead>
                <tr>
                    <th>#</th><th>Integridad</th><th>Identidad</th>
                    <th>Nombre</th><th>Apellido</th><th>Correo</th>
                    <th>Teléfono</th><th>Sexo</th><th>Edad</th>
                    <th>País</th><th>Nacionalidad</th><th>Temas</th>
                    <th>Observaciones</th><th>Fecha</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($inscriptores as $r): ?>
                <?php $integro = InscriptorModel::verify($r); ?>
                <tr>
                    <td><?= $r['id_inscriptor'] ?></td>
                    <td><?php if ($integro): ?>
                        <span class="badge badge-ok"> Íntegro</span>
                    <?php else: ?>
                        <span class="badge badge-err"> Comprometido</span>
                    <?php endif; ?></td>
                    <td><?= htmlspecialchars($r['identidad']) ?></td>
                    <td><?= htmlspecialchars($r['nombre']) ?></td>
                    <td><?= htmlspecialchars($r['apellido']) ?></td>
                    <td><?= htmlspecialchars($r['correo']) ?></td>
                    <td><?= htmlspecialchars($r['celular']) ?></td>
                    <td><?= htmlspecialchars($r['sexo']) ?></td>
                    <td><?= $r['edad'] ?></td>
                    <td><?= htmlspecialchars($r['nombre_pais']) ?></td>
                    <td><?= htmlspecialchars($r['nacionalidad']) ?></td>
                    <td style="font-size:.8rem; color:#34D399"><?= htmlspecialchars($r['temas'] ?? '—') ?></td>
                    <td style="font-size:.8rem"><?= htmlspecialchars(mb_strimwidth($r['observaciones'] ?? '', 0, 50, '…')) ?></td>
                    <td style="white-space:nowrap; font-size:.8rem"><?= $r['fecha_registro'] ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        </div>
        <?php endif; ?>
    </div>

    <footer class="site-footer">
        <strong>© <?= date('Y') ?> Capital Humano. All rights reserved.</strong><br>
         <a href="mailto:info@capitalhumano.pa">info@capitalhumano.pa</a>
        &nbsp;&bull;&nbsp;  +507 6767-6767
        &nbsp;&bull;&nbsp;  <a href="#">www.CapitalHumano.pa</a>
    </footer>

</div>
</body>
</html>
