<?php
/**
 * exports/export.php — Exportar inscripciones a Excel
 */
session_start();

require_once __DIR__ . '/../vendor/autoload.php';
require_once __DIR__ . '/../config/Database.php';
require_once __DIR__ . '/../models/InscriptorModel.php';

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;

// Inicialización y carga de datos
InscriptorModel::initKeys();
$rows = InscriptorModel::getAll();

$spreadsheet = new Spreadsheet();
$sheet = $spreadsheet->getActiveSheet();
$sheet->setTitle('Inscripciones DevConnect');

// Helpers para estilos y escritura
function applyStyle($sheet, $range, array $style)
{
    $sheet->getStyle($range)->applyFromArray($style);
}

function put($sheet, $cell, $value)
{
    $sheet->setCellValue($cell, $value);
}

// Estilos reutilizables
$titleStyle = [
    'font' => ['bold' => true, 'size' => 14, 'color' => ['rgb' => 'FFFFFF']],
    'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => '065F46']],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER],
];

$subtitleStyle = [
    'font' => ['size' => 10, 'italic' => true, 'color' => ['rgb' => '6D28D9']],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
];

$headerStyle = [
    'font' => ['bold' => true, 'color' => ['rgb' => 'FFFFFF'], 'size' => 10],
    'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => '0D3320']],
    'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER, 'vertical' => Alignment::VERTICAL_CENTER],
    'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => '065F46']]],
];

// --- Encabezado principal ---
$sheet->mergeCells('A1:N1');
put($sheet, 'A1', '© ' . date('Y') . ' Capital Humano —  Reporte de Inscripciones');
applyStyle($sheet, 'A1', $titleStyle);
$sheet->getRowDimension(1)->setRowHeight(30);

// --- Línea informativa ---
$sheet->mergeCells('A2:N2');
put($sheet, 'A2', 'Generado el: ' . date('d/m/Y H:i:s') . '   |   Total registros: ' . count($rows));
applyStyle($sheet, 'A2', $subtitleStyle);

// --- Cabeceras de columna ---
$columns = [
    'A' => '#', 'B' => 'Integridad', 'C' => 'Identidad', 'D' => 'Nombre', 'E' => 'Apellido',
    'F' => 'Correo', 'G' => 'Celular', 'H' => 'Sexo', 'I' => 'Edad', 'J' => 'País de Residencia',
    'K' => 'Nacionalidad', 'L' => 'Temas de Interés', 'M' => 'Observaciones', 'N' => 'Fecha de Registro',
];

foreach ($columns as $col => $label) {
    put($sheet, $col . '3', $label);
}
applyStyle($sheet, 'A3:N3', $headerStyle);
$sheet->getRowDimension(3)->setRowHeight(22);

// --- Rellenar filas ---
$rIndex = 4;
foreach ($rows as $item) {
    $ok = InscriptorModel::verify($item);
    $stripe = ($rIndex % 2 === 0) ? 'F0FDF4' : 'FFFFFF';

    put($sheet, 'A' . $rIndex, $item['id_inscriptor']);
    put($sheet, 'B' . $rIndex, $ok ? ' Íntegro' : ' Comprometido');
    put($sheet, 'C' . $rIndex, $item['identidad']);
    put($sheet, 'D' . $rIndex, $item['nombre']);
    put($sheet, 'E' . $rIndex, $item['apellido']);
    put($sheet, 'F' . $rIndex, $item['correo']);
    put($sheet, 'G' . $rIndex, $item['celular']);
    put($sheet, 'H' . $rIndex, $item['sexo']);
    put($sheet, 'I' . $rIndex, $item['edad']);
    put($sheet, 'J' . $rIndex, $item['nombre_pais']);
    put($sheet, 'K' . $rIndex, $item['nacionalidad']);
    put($sheet, 'L' . $rIndex, $item['temas'] ?? '');
    put($sheet, 'M' . $rIndex, $item['observaciones'] ?? '');
    put($sheet, 'N' . $rIndex, $item['fecha_registro']);

    // Estilos condicionales para integridad
    $colorText = $ok ? '065F46' : '991B1B';
    $colorBg   = $ok ? 'D1FAE5' : 'FEE2E2';
    applyStyle($sheet, 'B' . $rIndex, [
        'font' => ['bold' => true, 'color' => ['rgb' => $colorText]],
        'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => $colorBg]],
        'alignment' => ['horizontal' => Alignment::HORIZONTAL_CENTER],
    ]);

    // Fondo por fila y bordes
    applyStyle($sheet, 'A' . $rIndex . ':N' . $rIndex, [
        'fill' => ['fillType' => Fill::FILL_SOLID, 'startColor' => ['rgb' => $stripe]],
        'borders' => ['allBorders' => ['borderStyle' => Border::BORDER_THIN, 'color' => ['rgb' => 'CBD5E1']]],
        'alignment' => ['vertical' => Alignment::VERTICAL_CENTER],
    ]);

    $sheet->getRowDimension($rIndex)->setRowHeight(18);
    $rIndex++;
}

// --- Ajuste de anchos de columna ---
$colWidths = ['A'=>6,'B'=>16,'C'=>14,'D'=>18,'E'=>18,'F'=>28,'G'=>16,
           'H'=>8,'I'=>7,'J'=>20,'K'=>16,'L'=>40,'M'=>30,'N'=>20];
foreach ($colWidths as $c => $w) {
    $sheet->getColumnDimension($c)->setWidth($w);
}

// Mantener cabeceras visibles
$sheet->freezePane('A4');

// Preparar descarga (mismo resultado que antes)
$filename = 'inscripciones_itech_' . date('Ymd_His') . '.xlsx';
header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
header('Content-Disposition: attachment; filename="' . $filename . '"');
header('Cache-Control: max-age=0');

$writer = new Xlsx($spreadsheet);
$writer->save('php://output');
exit;
